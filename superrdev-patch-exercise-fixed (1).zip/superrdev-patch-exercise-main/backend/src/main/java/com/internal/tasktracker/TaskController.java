package com.internal.tasktracker;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
public class TaskController {

    private final TaskRepository taskRepository;

    public TaskController(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    @GetMapping("/api/tasks")
    public ResponseEntity<?> searchTasks(
            @RequestParam(required = false, defaultValue = "") String q,
            @RequestParam(required = false) String status,
            @RequestParam(required = false, defaultValue = "1") int page,
            @RequestParam(required = false, defaultValue = "10") int pageSize) {

        // Normalize query input
        String query = q == null ? "" : q.trim();
        String searchTerm = "%" + query.toLowerCase() + "%";

        // Keep pagination values within safe, predictable bounds.
        page = Math.max(1, page);
        pageSize = Math.max(1, Math.min(pageSize, 100));

        // Validate the optional status filter instead of allowing invalid values
        // to become an unhandled server error.
        String normalizedStatus = null;
        if (status != null && !status.isBlank()) {
            try {
                normalizedStatus = TaskStatus.valueOf(status.trim().toUpperCase(Locale.ROOT)).name();
            } catch (IllegalArgumentException e) {
                Map<String, String> error = new LinkedHashMap<>();
                error.put("error", "Invalid status. Expected OPEN, IN_PROGRESS, or DONE.");
                return ResponseEntity.badRequest().body(error);
            }
        }

        List<Task> allResults = taskRepository.searchTasks(searchTerm, normalizedStatus);

        long startOffset = ((long) page - 1) * pageSize;
        List<Task> pageResults;
        if (startOffset >= allResults.size()) {
            pageResults = Collections.emptyList();
        } else {
            int start = (int) startOffset;
            int end = Math.min(start + pageSize, allResults.size());
            pageResults = allResults.subList(start, end);
        }

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("items", pageResults);
        response.put("total", allResults.size());
        response.put("page", page);
        response.put("pageSize", pageSize);

        return ResponseEntity.ok(response);
    }
}
