# Patch Notes

## Summary of changes
- Fixed task-search SQL precedence so archived tasks are always excluded and the optional status filter applies to matches in either title or description. Applied the same logic to the SQL reference files.
- Removed artificial request sleeping from the controller, which added avoidable latency to every search.
- Normalized invalid pagination values and capped page size to prevent negative offsets and excessively large responses. Invalid status values now return HTTP 400 with a useful message rather than an unhandled server error.
- Fixed frontend request state handling: clear previous errors when retrying, always end loading after success/failure, and ignore stale responses after filter changes. Reset pagination when the search or status filter changes.
- Removed a development-only API URL console log and added an ID tie-breaker for deterministic ordering when timestamps match.

## What I chose not to change
I did not rewrite the app, add a new state-management library, or introduce backend pagination at the database layer. Those changes are larger than needed for this focused exercise. The backend still loads matching tasks before slicing the requested page, which may become inefficient as the dataset grows.

## Biggest remaining risk
Search currently loads all matching rows into memory before pagination. For a much larger task table, database-level pagination and a separate count query would be preferable.

## Tools used
I used ChatGPT to review the source, discuss likely root causes, and help draft focused changes. I reviewed the changed code. Automated builds were not available in this environment because dependency downloads could not complete, so the frontend build and backend startup still need to be verified locally before submission.
